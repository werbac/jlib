# ModelS - [Julia](http://julialang.org)

#[![Build Status](https://travis-ci.org/dmbates/MixedModels.jl.svg?branch=master)](https://travis-ci.org/dmbates/MixedModels.jl)
[![Coverage Status](https://img.shields.io/coveralls/dmbates/MixedModels.jl.svg)](https://coveralls.io/r/dmbates/MixedModels.jl?branch=master)
[![MixedModels](http://pkg.julialang.org/badges/MixedModels_0.3.svg)](http://pkg.julialang.org/?pkg=MixedModels&ver=0.3)
[![MixedModels](http://pkg.julialang.org/badges/MixedModels_0.4.svg)](http://pkg.julialang.org/?pkg=MixedModels&ver=0.4)

#### Julia Sstuff 
#1. F
- agregato the mean of the dependent values
