- is the type of `ranef(fittedmodel)` consistent?

