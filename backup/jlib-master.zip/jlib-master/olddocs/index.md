# `MixedModels`


A package for fitting linear mixed-effects models such as those fit by the [`lme4`](https://github.com/lme4/lme4) package for [`R`](http://www.r-project.org).
